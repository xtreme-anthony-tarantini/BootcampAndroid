/** Automatically generated file. DO NOT MODIFY */
package bootcamp.android.twieber;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}